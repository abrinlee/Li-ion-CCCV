import re
import csv

# Open the input file
with open('Li-Ion CCCV Charger.sch', 'r') as file:
    data = file.read()

# Find symbol and lib_id
symbol_blocks = re.findall(r'\(symbol\s+\(lib_id\s+"([^"]+)"\).*?\n\s+\)', data, re.DOTALL)

# Create a dictionary to store the unique references for each lib_id
symbol_refs = {}
for block in symbol_blocks:
    lib_id_match = re.search(r'\(lib_id\s+"([^"]+)"', block)
    ref_match = re.search(r'\(property\s+"Reference"\s+"([^"]+)"', block)
    if lib_id_match:
        lib_id = lib_id_match.group(1)
        if ref_match:
            ref = ref_match.group(1)
        else:
            ref = ""
        symbol_refs[lib_id] = ref

# Write the data to the output CSV file
with open('output.csv', 'w', newline='') as csvfile:
    writer = csv.writer(csvfile)
    writer.writerow(['Ref', 'lib_id'])  # Write the header row
    for lib_id, ref in symbol_refs.items():
        parsed_lib_id = re.sub(r'^[^:]+:', '', lib_id)  # Remove library name and colon
        writer.writerow([ref.strip(), parsed_lib_id])
